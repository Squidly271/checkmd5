#!/bin/bash

/usr/local/emhttp/plugins/check_md5/scripts/checkmd5.sh &
sleep 5

